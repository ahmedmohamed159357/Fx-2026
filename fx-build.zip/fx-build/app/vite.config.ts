import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const BACKEND = process.env.VITE_API_URL || 'http://localhost:4002'

export default defineConfig({
  plugins: [react()],

  server: {
    port: 5173,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: BACKEND,
        changeOrigin: true,
        secure: false,
      },
      '/health': {
        target: BACKEND,
        changeOrigin: true,
        secure: false,
      },
      '/healthz': {
        target: BACKEND,
        changeOrigin: true,
        secure: false,
      },
    },
  },

  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom'],
          'vendor-pdf':   ['jspdf'],
        },
      },
    },
    sourcemap: false,
    minify: 'esbuild',
  },
})
