#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND="$ROOT/backend"
FRONTEND="$ROOT/app"

# ── env files ────────────────────────────────────────────────────────────────
if [[ ! -f "$BACKEND/.env" ]]; then
  echo "[run.sh] ERROR: $BACKEND/.env not found."
  echo "         Copy backend/.env.example to backend/.env and set OPENAI_API_KEY."
  exit 1
fi

if [[ ! -f "$FRONTEND/.env" ]]; then
  echo "VITE_API_URL=http://localhost:4002" > "$FRONTEND/.env"
  echo "[run.sh] Created app/.env with VITE_API_URL=http://localhost:4002"
fi

# ── install ───────────────────────────────────────────────────────────────────
echo "[run.sh] Installing backend dependencies..."
cd "$BACKEND"
npm install --ignore-scripts

echo "[run.sh] Installing frontend dependencies..."
cd "$FRONTEND"
npm install

# ── start ─────────────────────────────────────────────────────────────────────
echo "[run.sh] Starting backend on :4002..."
cd "$BACKEND"
npm run dev &
BACKEND_PID=$!

echo "[run.sh] Waiting for backend..."
for i in $(seq 1 20); do
  if curl -sf http://localhost:4002/health >/dev/null 2>&1; then
    echo "[run.sh] Backend ready."
    break
  fi
  sleep 1
done

echo "[run.sh] Starting frontend on :5173..."
cd "$FRONTEND"
npm run dev &
FRONTEND_PID=$!

cleanup() {
  echo "[run.sh] Shutting down..."
  kill "$BACKEND_PID"  2>/dev/null || true
  kill "$FRONTEND_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

echo ""
echo "  Backend:  http://localhost:4002/health"
echo "  Frontend: http://localhost:5173"
echo ""
wait
